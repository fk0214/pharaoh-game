# 法老秘境 Phaser 網頁遊戲原型

這是一個免費虛擬金幣的原創古埃及主題消除遊戲原型，使用 Phaser 3 與 JavaScript，可部署到靜態網站服務，並在 iPhone Safari 開啟。

## 檔案
- `index.html`：完整遊戲程式（HTML、CSS、JavaScript、Phaser 3 CDN）。

## 本機測試
1. 將 `index.html` 放在資料夾中。
2. 建議用 VS Code 安裝 Live Server 擴充功能。
3. 在 `index.html` 按右鍵 → **Open with Live Server**。
4. 用瀏覽器測試旋轉、下注金額、連鎖消除、紀錄和重設。

也可以直接雙擊 HTML 測試，但部分瀏覽器對本機檔案的限制可能影響體驗；正式使用建議透過 HTTPS 網站開啟。

## 部署到 GitHub Pages
1. 登入 GitHub 並建立新的公開 Repository，例如 `pharaoh-game`。
2. 上傳 `index.html`。
3. 開啟 Repository 的 **Settings → Pages**。
4. 在 Build and deployment 選擇 **Deploy from a branch**。
5. Branch 選 `main`，資料夾選 `/(root)`，按 Save。
6. 等待 GitHub Pages 部署完成，網址通常為 `https://你的帳號.github.io/pharaoh-game/`。
7. 在 iPhone Safari 開啟該網址。可以透過 Safari 分享按鈕 →「加入主畫面」。

## 遊戲規則
- 6 欄 × 5 列。
- 連通的相同符號達 8 個或以上時消除。
- 消除後圖示下落、補入新圖示，最多檢查 10 次連鎖。
- 獎勵以下注、符號權重、群組大小和連鎖倍率計算。
- 金幣與遊戲紀錄保存在該瀏覽器的 localStorage。

## 注意
- 需要網路載入 Phaser CDN。
- 這是遊戲原型，未包含帳號、伺服器同步或多人遊戲。
- 所有金幣皆為虛擬娛樂點數，無法兌換現金。
- 本專案使用原創介面與符號組合，並非 ATG 官方產品。
